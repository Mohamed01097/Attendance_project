# -*- coding: utf-8 -*-
# from odoo import http


# class FacuTrack(http.Controller):
#     @http.route('/facu_track/facu_track', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/facu_track/facu_track/objects', auth='public')
#     def list(self, **kw):
#         return http.request.render('facu_track.listing', {
#             'root': '/facu_track/facu_track',
#             'objects': http.request.env['facu_track.facu_track'].search([]),
#         })

#     @http.route('/facu_track/facu_track/objects/<model("facu_track.facu_track"):obj>', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('facu_track.object', {
#             'object': obj
#         })
