from odoo import models, fields

import openpyxl






class Course(models.Model):
    _name = 'facu_track.course'
    _description = 'Faculty Course'

    name = fields.Char(required=True)
    code = fields.Char(string='Course Code', required=True)
    prof_id = fields.Many2one('facu_track.prof', string='Professor', required=True)
    email = fields.Char(string = "Email")
    color = fields.Char(string="Color")
    datetime = fields.Datetime(default=fields.Datetime.now,string="Date Of Get Report")
    student_ids = fields.One2many('facu_track.student','course_id', string='Students')
    l10n_ke_cu_qrcode = fields.Char(string='CU QR Code', copy=False)

    dataframe = openpyxl.load_workbook("/home/mohamed/odoo/15c/custom/facu_track/models/data.xlsx")

    # Define variable to read sheet
    dataframe1 = dataframe.active

    # Iterate the loop to read the cell values
    def lst_of_names(self):
        lst_names = []
        for row in range(self.dataframe1.max_row):
            for col in self.dataframe1.iter_cols(1, self.dataframe1.max_column):
                lst_names.append(col[row].value)
        return lst_names

    def test(self):
        pass

    def create_new_users(self):
        for user in range(len(self.lst_of_names())):
            self.env['res.users'].create({
                'name':self.student_ids.name,
                ''
            })