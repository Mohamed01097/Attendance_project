# -*- coding: utf-8 -*-

from . import models
from . import student
from . import course
from . import professor
from . import department
from . import create_invoice_criedit_note_inventory
