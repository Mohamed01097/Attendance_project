# -*- coding: utf-8 -*-
from odoo import models, fields, api
import random

class Student(models.Model):
    _name = 'facu_track.student'
    _description = 'facu_track.student'

    name = fields.Char(required=True)
    code = fields.Char(required=True,string="Student Code")
    group = fields.Integer(required=True)
    dept_id = fields.Many2one('facu_track.dept',string="Department")
    course_id = fields.Many2one('facu_track.course',string="course")
    date = fields.Datetime(string="Date Of Attend")
    prof_id = fields.Many2one('facu_track.prof',string="Professor",related='course_id.prof_id')

