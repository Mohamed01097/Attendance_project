def return_new_data(lst:list):
    new_data = []
    for i in lst:
        if i not in new_data:
            new_data.append(i)
        else:
            continue
    return new_data

