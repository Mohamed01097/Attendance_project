# import pandas as pd
# dataframe1 = pd.read_excel('data.xlsx')

import openpyxl

# Define variable to load the dataframe
dataframe = openpyxl.load_workbook("data.xlsx")

# Define variable to read sheet
dataframe1 = dataframe.active
# Iterate the loop to read the cell values
def lst_of_names ():
    lst_names = []
    for row in range(dataframe1.max_row):
        for col in dataframe1.iter_cols(1, dataframe1.max_column):
            lst_names.append(col[row].value)
    return lst_names



