import xlsxwriter
import return_data
import StudentNames
from openpyxl import Workbook


workbook = xlsxwriter.Workbook('student.xlsx')
workbook.close()


workbook = Workbook()
#
sheet = workbook.active


for row in return_data.return_new_data(StudentNames.return_data()):
    sheet.append(row)

workbook.save('data.xlsx')
