import random
import pandas as pd
import xlsxwriter


def generate_random_emails(full_name):
    first_name = full_name.split(" ")
    return first_name[0]+str(random.randint(1000,10000))+"@fcal"

df_names = pd.read_excel(r'/home/mohamed/odoo/15c/custom/facu_track/models/data.xlsx')


def return_student_emails():
    list_of_emails = [generate_random_emails(email[0]) for email in df_names.values]
    return list_of_emails


for email in return_student_emails():
    print(email)