from odoo import api, fields, models

class StudentAttendanceReport(models.Model):
    _name = 'student.attendance.report'
    _description = 'Student Attendance Report'
